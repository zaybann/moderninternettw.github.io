document.addEventListener('DOMContentLoaded', function () {
    const wavesContainer = document.createElement('div');
    wavesContainer.classList.add('waves-container');

    for (let i = 0; i < 3; i++) {
        const wave = document.createElement('div');
        wave.classList.add('wave');
        wavesContainer.appendChild(wave);
    }

    document.body.appendChild(wavesContainer);
});
